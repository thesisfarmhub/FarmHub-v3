﻿namespace FarmHub.Areas.Admin.Models
{
    public class SeedAutoCompleteModel
    {
        public int Id_Seed { get; set; }

        public string Name_Seed { get; set; }

        public string Code_Seed { get; set; }
    }
}