﻿namespace FarmHub.Areas.Admin.Models
{
    public class ProductAutoCompleteModel
    {
        public int Id_Product { get; set; }

        public string Name_Product { get; set; }
    }
}