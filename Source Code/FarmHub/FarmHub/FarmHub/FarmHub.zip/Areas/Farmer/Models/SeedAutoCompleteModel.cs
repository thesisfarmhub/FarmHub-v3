﻿namespace FarmHub.Areas.Farmer.Models
{
    public class SeedAutoCompleteModel
    {
        public int Id_Seed { get; set; }

        public string Name_Seed { get; set; }
    }
}